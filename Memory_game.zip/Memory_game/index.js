import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

const Alphabets = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

// to shuffle elements of an array

Alphabets.sort(() =>
{ return 0.5 - Math.random() 
});

let count = 0;
let flag  = 0;

let currState = null;

class Square extends React.Component {
	
	render() {
		return (
		<div>
		<button className="square" onClick={this.props.onClick}>
			{this.props.value}
		</button>
		</div>
		);
	}
}

class Board extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = { 
		squares: Array(16).fill(null),
		prevState: null
		};
		this.handleClick = this.handleClick.bind(this);
		this.onReset = this.onReset.bind(this);
	}
	
	handleClick(i) {

		let squares = this.state.squares.slice();
		
		if(squares[i]) {
			return;
		}
		squares[i] = Alphabets[i];
		
		flag++;
		
		currState = Alphabets[i]; 
		
		if(flag >= 2)
		{
			if(this.state.prevState === currState)
			{
				this.match();	
			}
			else
			{
			this.notMatch();
			}
		}		
		
		this.setState({
			squares: squares,
			prevState: Alphabets[i]
		});	
	}
	
	renderSquare(i) {
		return (
		
		<Square 
		value={this.state.squares[i]}
		onClick = {() => {this.handleClick(i)}}
		/>
		);
	}
	
	match() {
		count++;
		currState = '*';
// if match, put * to amrk it as completed
		const value = '*'; 
		this.setState({
			prevState: value
		});
	}
	
	notMatch() {
		
		currState = null;
		this.setState({
			prevState: null
		});
	
		//currState = null;
		//this.setState({prevState: null});	
		//alert(no match);
	}
	
	onReset() {
		
		count = 0;
		flag = 0;
		this.setState ({
			squares: Array(16).fill(null)
		})
		
	}
	
	render() {

		return (
		
			<div>
				<h1>Lets play a game!!!</h1>
				<div className="board-row">
				{this.renderSquare(0)}
				{this.renderSquare(1)}
				{this.renderSquare(2)}
				{this.renderSquare(3)}
				</div>
				<div className="board-row">
				{this.renderSquare(4)}
				{this.renderSquare(5)}
				{this.renderSquare(6)}
				{this.renderSquare(7)}
				</div>
				<div className="board-row">
				{this.renderSquare(8)}
				{this.renderSquare(9)}
				{this.renderSquare(10)}
				{this.renderSquare(11)}
				</div>
				<div className="board-row">
				{this.renderSquare(12)}
				{this.renderSquare(13)}
				{this.renderSquare(14)}
				{this.renderSquare(15)}
				</div> <br />
				
				<h2>Score: {count}</h2>
				<h2>No. of Clicks: {flag}</h2>
				<button onClick={this.onReset}>Reset</button>
				
			</div>
		);
	}
}


ReactDOM.render(
<Board />, document.getElementById('root')
);
