//search_bar.js
// event hadling in js has 2 main steps: 
//1st: create event handler like onInputChange in this example
//2nd: associate that event handler with the component we want to monitor like <input /> in this example

import React from 'react';
	
	
// 1st method: function based component
 /*
const SearchBar = () => {
	return <input />;
	}
	
export default SearchBar;

*/

// 2nd method: class based component
/*
class SearchBar extends React.Component{
	
	render(){
		return <input onChange={this.onInputChange} />;
		}
		
	onInputChange(event){
	console.log(event.target.value);
	}
	
}

*/



//3rd: more precise code for event handler

export class SearchBar extends React.Component{

	constructor(props){
		super(props);
		
		this.state = { term: '' };
		this.handleChange = this.handleChange.bind(this);
	}
	
	handleChange(term) {
		this.setState ({term});
		this.props.onSearchTermChange(term);
	}
	
	render(){
		return(
		<div className="search-bar"> 
		<input
		value={this.state.term} 
		onChange={event => this.handleChange(event.target.value)} />
		
		</div>
		);
	}
} 
