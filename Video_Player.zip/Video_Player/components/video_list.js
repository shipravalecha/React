//video_list.js
// array.map is used in javascript if we want to get list of items. or to iterate through array items.
import React from 'react';
import { VideoListItem } from './video_list_item.js';

export const VideoList = (props) => {

const videoItems = props.videos.map((video) => {
	return (
	<VideoListItem 
	onVideoSelect={props.onVideoSelect}
	key={video.etag}
	video={video} /> 
	);
	});
	
	return (
	<ul className="col-md-4 list-group">
	{videoItems}
	</ul>
	);
};