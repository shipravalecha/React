
// React: in React we write different javascript code and components and React has some javascript function that
// produce HTML out of the javascript code so that it can be visible to the user on browser.
// create a new component which will produce some HTML...

// const used to declare variables... this is used in ES6 similar to var of ES5
// JSX: it allows us to write looks like HTML code inside our js code like below.
// JSX looks like HTML
// purpose of JSX is to produce the actual HTML code that needs to be placed in DOM
	// use => instead of function keyword

// React take this component generated HTML and put it on the page (in the dom)
// the component that we created above App, we cannot pass it to the dom, we need to create instance of that component like <App></App> or <App />
import _ from 'lodash';
import React from 'react';
import ReactDOM from 'react-dom';
import YTSearch from 'youtube-api-search';
import { SearchBar } from './components/search_bar.js';
import { VideoList } from './components/video_list.js';
import { VideoDetail } from './components/video_detail.js';

	
const API_KEY = 'AIzaSyCw86DTyNLqa9AKfE4sw2_ctA4P8QYfgks';
	
class App extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = {
			videos: [],
			selectedVideo: null
		};
		this.videoSearch('surfboards');
};

videoSearch(term) {
	 YTSearch({ key: API_KEY, term: term }, (videos) => {
	  this.setState({
		  videos: videos,
		  selectedVideo: videos[0]  
		  });
		// in ES6: if key value are same then use a single variable: this.setState({ videos: videos })
	});	
}
	

render() {
	const videoSearch = _.debounce((term) => { this.videoSearch(term) }, 300);
	return (
	<div>
		<SearchBar onSearchTermChange={videoSearch} />
		<VideoDetail video={this.state.selectedVideo} />
		<VideoList
		onVideoSelect={selectedVideo => this.setState({selectedVideo}) }
		videos={this.state.videos} />
	</div>
	);
}
	
};


ReactDOM.render(<App />, document.querySelector('.container'));
